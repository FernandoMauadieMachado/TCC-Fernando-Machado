from flask import Flask, request, render_template
import pandas as pd
import joblib


# Declare a Flask app
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def main():
    
    # If a form is submitted
    if request.method == "POST":
        
        # Unpickle classifier
        clf = joblib.load("clf.pkl")
        pca = joblib.load("pca.pkl")
        # Get values through input bars
        Arq = request.form.get("Arquivo")
        # Put inputs to dataframe
        X = pd.read_csv(Arq)
        del X['1']
        del X['3']
        X = X.drop('2', axis=1)
        X = pca.transform(X)
            
        # Get prediction
        prediction = clf.predict(X)
        if prediction == 1:
            prediction = "Ransomware"
        elif prediction == 0:
            prediction = "Goodware"
    else:
        prediction = ""
        
    return render_template("site.html", output = prediction)

# Running the app
if __name__ == '__main__':
    app.run(debug = True)
