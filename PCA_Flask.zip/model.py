import pandas as pd


df = pd.read_csv("data.csv")

df2 = df.copy()
del df2['1']
del df2['3']
print(df2)

df4 = df2.copy()
y=df4['2']
X=df4.drop('2',axis=1)


#PCA

from sklearn.decomposition import PCA
pca = PCA(0.90)
X = pca.fit_transform(X)
#regressão logistica

from sklearn.linear_model import LogisticRegression
clf = LogisticRegression()
clf.fit(X, y)

import joblib

joblib.dump(clf, "clf.pkl")
joblib.dump(pca,"pca.pkl")

