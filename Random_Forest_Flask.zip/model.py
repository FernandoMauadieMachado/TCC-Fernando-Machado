import pandas as pd


df = pd.read_csv("data.csv")

df2 = df.copy()
del df2['1']
del df2['3']
print(df2)

df4 = df2.copy()
y=df4['2']
X=df4.drop('2',axis=1)


#random Forest

from sklearn.model_selection import train_test_split
  
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)

from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectFromModel

sel = SelectFromModel(RandomForestClassifier(random_state=0))
sel.fit(X_train, y_train)

sel.get_support()

selected_feat= X_train.columns[(sel.get_support())]

print(len(selected_feat))

df5 = pd.DataFrame()

for i in range(len(selected_feat)):
    df5[i] = X[selected_feat[i]].copy()
print(df5)
print(df5.isnull().values.any())
#regressão logistica

from sklearn.linear_model import SGDClassifier
y2=df4['2']
X2=df5


clf = SGDClassifier(loss='squared_hinge', penalty='l1', random_state=10,max_iter=10000)
clf.fit(X2, y2)

import joblib

joblib.dump(clf, "clf.pkl")
joblib.dump(selected_feat,"features.pkl")
