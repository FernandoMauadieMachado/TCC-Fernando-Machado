from flask import Flask, request, render_template
import pandas as pd
import joblib


# Declare a Flask app
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def main():
    
    # If a form is submitted
    if request.method == "POST":
        
        # Unpickle classifier
        clf = joblib.load("clf.pkl")
        features = joblib.load("features.pkl")
        print(features)
        lista = []
        # Get values through input bars
        Arq = request.form.get("Arquivo")
        
        estado = False
        # Put inputs to dataframe
        X = pd.read_csv(Arq)
        for i in range(1,30971):
            for a in range(len(features)):
                if str(i) == features[a]:
                    estado = True
            if estado == False:
                lista.append(str(i))
            estado = False
        X = X.drop(lista,axis=1)
            
        # Get prediction
        prediction = clf.predict(X)
        if prediction == 1:
            prediction = "Ransomware"
        elif prediction == 0:
            prediction = "Goodware"
    else:
        prediction = ""
        
    return render_template("site.html", output = prediction)

# Running the app
if __name__ == '__main__':
    app.run(debug = True)
