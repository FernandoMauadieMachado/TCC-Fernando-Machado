import pandas as pd
import csv

df = pd.read_csv("RansomwareData3.csv")

df2 = df.copy()

pos = [2,28,592,1514,513]

for i in range(0,5):
    df3 = df2.iloc[[pos[i]]]
    df3.to_csv('linha'+str(pos[i])+'.csv', index=False)

for i in range(0,5):
    df2 = df2.drop(pos[i])
df2.to_csv('data.csv',index=False)
